library(shiny)
library(tidyverse)
library(stringr)
significance <- read.csv('significance.csv', stringsAsFactors = FALSE)

ui <- fluidPage(
    titlePanel(h1('Phanalytix')),
    titlePanel(h3('Virtual Concert Reccomendation')),
    
    sidebarLayout(
        sidebarPanel(h4('Rank your preferences:'),
                     
        
            dateRangeInput(inputId = 'dateRange',
                    label = "Include dates from:",
                    start = min(significance$date),
                    min = min(significance$date),
                    end = max(significance$date),
                    max = Sys.Date(),
                    format = 'yyyy-mm-dd'),
            
            sliderInput(inputId = 'lengthVal', 
                    label = "Song Length", 
                    min = 0, 
                    max = 5, 
                    value = 3),
            
            sliderInput(
                    inputId = 'gapVal',
                    label = "Gap at time of Performance (Bustouts)",
                    min = 1,
                    max = 5,
                    value = 4),

            sliderInput(
                    inputId = 'rotationVal',
                    label = "Rotation (How often a song is played, on average)",
                    min = 1,
                    max = 5,
                    value = 2),

            sliderInput(
                    inputId = 'ratingVal',
                    label = "Show Rating from Phish.Net",
                    min = 1,
                    max = 5,
                    value = 5),

            sliderInput(
                    inputId = 'sinceDebutVal',
                    label = "Age of a song",
                    min = 1,
                    max = 5,
                    value = 1),
            
            sliderInput(
                inputId = 'coverVal',
                label = "Covers",
                min = 1,
                max = 5,
                value = 1),
            
            sliderInput(
                inputId = 'debutVal',
                label = "Live Debuts",
                min = 1,
                max = 5,
                value = 1),
            
            sliderInput(
                inputId = 'teaseVal',
                label = "Teases & Quotes",
                min = 1,
                max = 5,
                value = 4),
            
            sliderInput(
                inputId = 'notesVal',
                label = "Oddities: acoustic, a capella, musical guests",
                min = 1,
                max = 5,
                value = 3)
            
        ),
        mainPanel(
            dataTableOutput("reccomended")
        )
    )#,
    
    #dataTableOutput("reccomended")
        
            
    
    
)
server <- function(input, output) {
        
    output$reccomended <- renderDataTable({
        
        lengthValue <- input$lengthVal/15
        gapValue <- input$gapVal/15
        rotationValue <- input$rotationVal/15
        ratingValue <- input$ratingVal/15
        sinceDebutValue <- input$sinceDebutVal/30
        coverBonus <- input$coverVal * 0.01
        debutBonus <- input$debutVal * 0.01
        notesBonus <- input$notesVal * 0.01
        teaseBonus <- input$teaseVal * 0.01
        
        significance %>%
            mutate(significance_rating = length_rating*lengthValue +
                       gap_rating*gapValue +
                       rotation_rating*rotationValue +
                       rating_rating*ratingValue +
                       since_debut_rating*sinceDebutValue +
                       cover_dummy*coverBonus +
                       debut_dummy*debutBonus +
                       notes_dummy*notesBonus +
                       tease_dummy*teaseBonus) %>% 
            group_by(date, location, venue_name) %>%
            summarise(avgRating = mean(significance_rating, na.rm = TRUE)) %>%
            filter(as.Date(date) >= as.Date(input$dateRange[1]) && as.Date(date) <= as.Date(input$dateRange[2])) %>%
            arrange(desc(avgRating)) %>%
            select(-avgRating) %>% 
            mutate("Stream Link" = str_c("phish.in/", date))
    })
}



shinyApp(ui = ui, server = server)