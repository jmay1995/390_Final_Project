library(shiny)
library(tidyverse)
library(stringr)
phanalytix <- read.csv('phanalytix.csv', stringsAsFactors = FALSE)
#significance <- read.csv('significance.csv', stringsAsFactors = FALSE)

ui <- navbarPage('Select a Function:',
                 position = 'static-top',
    titlePanel(h1('Phanalytix')),
    titlePanel(h3('Virtual Concert Reccomendation')),
               
    tabPanel("Find a Show",
             class="tab-pane active",
        sidebarLayout(
            sidebarPanel(h4('Rank your preferences:'),
                         
            
                dateRangeInput(inputId = 'dateRange',
                        label = "Only include dates from:",
                        start = min(phanalytix$date),
                        min = min(phanalytix$date),
                        end = max(phanalytix$date),
                        max = Sys.Date(),
                        format = 'yyyy-mm-dd'),
                
                sliderInput(inputId = 'lengthVal', 
                        label = "Song Length", 
                        min = 0, 
                        max = 5, 
                        value = 3),
                
                sliderInput(inputId = 'gapVal',
                        label = "Rarity of songs (aka Gap/Bustouts)",
                        min = 0,
                        max = 5,
                        value = 4),
    
                # sliderInput(inputId = 'rotationVal',
                #         label = "Rotation (How often a song is played, on average)",
                #         min = 0,
                #         max = 5,
                #         value = 2),
    
                sliderInput(inputId = 'ratingVal',
                        label = "Show Rating from Phish.Net",
                        min = 0,
                        max = 5,
                        value = 5),
                
                sliderInput(inputId = 'coverVal',
                    label = "Covers",
                    min = 0,
                    max = 5,
                    value = 1),
                
                sliderInput(inputId = 'debutVal',
                    label = "Live Debuts",
                    min = 0,
                    max = 5,
                    value = 1),
                
                sliderInput(inputId = 'teaseVal',
                    label = "Teases & Quotes",
                    min = 0,
                    max = 5,
                    value = 4),
                
                sliderInput(inputId = 'notesVal',
                    label = "Oddities: acoustic, a capella, musical guests",
                    min = 0,
                    max = 5,
                    value = 3),
                
                sliderInput(inputId = 'showAgeVal',
                            label = "Age of the show: 5 being older shows",
                            min = 0,
                            max = 5,
                            value = 0),
                
                sliderInput(inputId = 'invAgeVal',
                            label = "Age of the show: 5 being recent shows",
                            min = 0,
                            max = 5,
                            value = 0)
                
            ),
            mainPanel(
                dataTableOutput("reccomended")
            )
        )
    ),
    tabPanel("Show Map",
             leafletOutput("map"),
             p ())

)

server <- function(input, output) {
    
    song_length <- tibble(minutes = str_extract_all(phanalytix$duration_song, "[0-9]+(?=:)"), 
                          seconds = str_extract_all(phanalytix$duration_song, "(?<=:)[0-9]+"))
    
    song_length <- song_length %>% 
        mutate(minutes = as.numeric(minutes), 
               seconds = as.numeric(seconds))
    
    significance <- mutate(phanalytix, song_seconds = (song_length$minutes*60+song_length$seconds))
    
    significance <-  significance %>% 
        #Length Rating
        mutate(length_rating = song_seconds/max(significance$song_seconds, na.rm = TRUE),
               #Gap Rating
               gap_rating = adj_gap/max(significance$adj_gap, na.rm = TRUE),
               #Rotation Rating
               #rotation_rating = 1 - rotation/max(significance$rotation, na.rm = TRUE),
               #Rating Rating
               rating_rating = ratings/max(significance$ratings, na.rm = TRUE),
               #Debut Rating
               date = parse_date(date),
               debut = parse_date(debut),
               # since_debutThen = ifelse(as.numeric(date - debut) > 0, as.numeric(date - debut), 0),
               # since_debutNow = ifelse(as.numeric(Sys.Date() - debut) > 0, as.numeric(Sys.Date() - debut), 0),
               # since_debutThen_rating = since_debutThen/max(significance$since_debutThen, na.rm = TRUE),
               # since_debutNow_rating = since_debutNow/max(significance$since_debutNow, na.rm = TRUE),
               # since_debut_rating = (since_debutThen_rating + (since_debutNow_rating*5))/6,
               showAge = ifelse(as.numeric(Sys.Date() - date) > 0, as.numeric(Sys.Date() - date), 0),
               showAge_rating = showAge/max(showAge, na.rm = TRUE),
               invAge_rating = 1 - showAge_rating,
               #Debut Dummy Bonus
               debut_dummy = as.numeric(grepl('debut|first known', notes)),
               #Tease Dummy Bonus
               tease_dummy = as.numeric(grepl('tease|quote', notes)),
               #Notes Bonus
               notes_dummy = as.numeric(grepl('[qwertyuiopasdfghjklzxcvbnm]', notes)) 
                            - debut_dummy - tease_dummy, 
               notes_dummy = ifelse(notes_dummy<0, 0, notes_dummy)
        ) %>% 
        select(-showAge)
    
    output$reccomended <- renderDataTable({
        
        lengthValue <- input$lengthVal/10
        gapValue <- input$gapVal/10
        # rotationValue <- input$rotationVal/10
        ratingValue <- input$ratingVal/10
        showAgeValue <- input$showAgeVal/10
        invAgeValue <- input$invAgeVal/10
        coverBonus <- input$coverVal * 0.05
        debutBonus <- input$debutVal * 0.05
        notesBonus <- input$notesVal * 0.05
        teaseBonus <- input$teaseVal * 0.05
        
        significance %>%
            mutate(significance_rating = length_rating*lengthValue +
                       gap_rating*gapValue +
                       # rotation_rating*rotationValue +
                       rating_rating*ratingValue +
                       showAge_rating*showAgeValue +
                       invAge_rating*invAgeValue +
                       cover_dummy*coverBonus +
                       debut_dummy*debutBonus +
                       notes_dummy*notesBonus +
                       tease_dummy*teaseBonus) %>% 
            group_by(date, location, venue_name) %>%
            summarise(avgRating = mean(significance_rating, na.rm = TRUE)) %>%
            filter(as.Date(date) >= as.Date(input$dateRange[1]) && as.Date(date) <= as.Date(input$dateRange[2])) %>%
            arrange(desc(avgRating)) %>%
            #select(-avgRating) %>% 
            mutate("Stream Link" = str_c("phish.in/", date))
    })
    
    
    test <- significance %>% 
        group_by(venue_name, latitude, longitude, city, state, country) %>% 
        summarize(num_perform = n())
    
    output$map <- renderLeaflet({
        leaflet(test) %>% addTiles() %>%
            addMarkers( ~longitude, ~latitude, popup = paste("Number of songs performed at: ", 
                                                             as.character(test$venue_name), 
                                                             "=",  
                                                             as.character(test$num_perform)) )
        # addPolygons(fillColor = topo.colors(10, alpha = NULL), stroke = FALSE)
        
    })
}



shinyApp(ui = ui, server = server)