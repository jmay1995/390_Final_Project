library(dplyr)
library(ggplot2)
library(tidyr)
library(stringr)

library(rvest)
library(jsonlite)
library(tidyverse)

library(maps)
library(leaflet)
library(RColorBrewer)
library(ggmap)

phanalytix <- read.csv('phanalytix.csv', stringsAsFactors = FALSE)
shows <- read_csv('shows.csv')

# Clarifying datasets ----------------------------------------------------

phanalytix <- phanalytix[,c(1, 2, 20, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19)]


# Plots ------------------------------------------------------------------





