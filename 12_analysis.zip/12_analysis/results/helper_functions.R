#____________________________________________HELPER FUNCTIONS______________________________________________#

#write a function which converts the song time durations into minutes and seconds
song_parser <- function(x) {
    #formula to change original duration value into minutes and seconds
    adj_time <- trunc(x/60000)+((x/60000 - trunc(x/60000))*.6) 
    #parse the time as a character
    char_time <- parse_character(adj_time)
    #remove the slashes "\\." and replace with a dash "-"
    formatted_time <- str_replace(char_time, '\\.', '-')
    #parse as a time
    parsed_time <- strptime(formatted_time, format = "%M-%S")
    #change to only include the minutes and seconds
    duration_time <- strftime(parsed_time, format="%M:%S")
    
    #return the parsed duration value
    return(duration_time)
}

#write a function which converts the show time durations into hours and minutes
show_parser <- function(x) {
    #formula to change original duration value into hours and minutes
    adj_time2 <-  round(trunc(x / 3600000) + (((x / 3600000) - trunc(x / 3600000))*.6), digits=2) 
    #parse the time as a character
    char_time <- parse_character(adj_time2)
    #remove the slashes "\\." and replace with a dash "-"
    formatted_time <- str_replace(char_time, '\\.', '-')
    #parse as a time
    parsed_time <- strptime(formatted_time, format = "%H-%M")
    #change to only include the hours and minutes
    duration_time <- strftime(parsed_time, format="%H:%M")
    
    #return the parsed duration value
    return(duration_time)
}
